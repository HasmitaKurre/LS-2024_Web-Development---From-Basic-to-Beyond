import React from 'react';

const Tweet = ({ tweet, onEdit, onDelete }) => {
  return (
    <div className="tweet">
      <p>{tweet.content}</p>
      {tweet.media && <img src={tweet.media} alt="Tweet media" />}
      <button onClick={() => onEdit(tweet)}>Edit</button>
      <button onClick={() => onDelete(tweet.id)}>Delete</button>
    </div>
  );
};

export default Tweet;
