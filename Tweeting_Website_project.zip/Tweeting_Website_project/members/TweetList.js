import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Tweet from './Tweet';

const TweetList = () => {
  const [tweets, setTweets] = useState([]);

  useEffect(() => {
    const fetchTweets = async () => {
      const response = await axios.get('/api/tweets');
      setTweets(response.data);
    };

    fetchTweets();
  }, []);

  const handleDelete = async (id) => {
    await axios.delete(`/api/tweets/${id}`);
    setTweets(tweets.filter(tweet => tweet.id !== id));
  };

  const handleEdit = (tweet) => {
    // Handle edit logic
  };

  return (
    <div className="tweet-list">
      {tweets.map(tweet => (
        <Tweet key={tweet.id} tweet={tweet} onEdit={handleEdit} onDelete={handleDelete} />
      ))}
    </div>
  );
};

export default TweetList;
