import React, { useState } from 'react';
import axios from 'axios';

const NewTweet = () => {
  const [content, setContent] = useState('');
  const [media, setMedia] = useState(null);

  const handlePost = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append('content', content);
    if (media) formData.append('media', media);

    await axios.post('/api/tweets', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });

    setContent('');
    setMedia(null);
  };

  return (
    <form onSubmit={handlePost}>
      <textarea
        value={content}
        onChange={(e) => setContent(e.target.value)}
        placeholder="What's happening?"
      />
      <input type="file" onChange={(e) => setMedia(e.target.files[0])} />
      <button type="submit">Tweet</button>
    </form>
  );
};

export default NewTweet;
