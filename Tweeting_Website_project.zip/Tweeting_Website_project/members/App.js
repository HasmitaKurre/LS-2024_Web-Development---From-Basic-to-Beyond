import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import LoginForm from '.componentsLoginForm';
import TweetList from '.componentsTweetList';
import NewTweet from '.componentsNewTweet';

const App = () = {
  return (
    Router
      div className=App
        Switch
          Route path=login component={LoginForm} 
          Route path= exact
            NewTweet 
            TweetList 
          Route
        Switch
      div
    Router
  );
};

export default App;
